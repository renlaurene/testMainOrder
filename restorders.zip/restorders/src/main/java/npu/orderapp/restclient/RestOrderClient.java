package npu.orderapp.restclient;

import java.util.LinkedHashMap;

import npu.orderapp.domain.Order;
import npu.orderapp.exceptions.ResourceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

public class RestOrderClient {
	private static RestTemplate restTemplate = new RestTemplate();
	private final static String orderServiceUrl = "http://localhost:8080/restorders/orders/";
	
	public static Order getOrder(int id) {
		return restTemplate.getForObject(orderServiceUrl +"{id}", Order.class, id); 
	}
	
	/*  Get back a ResponseEntity rather than an object.   We can get the object by calling getBody().  */
	public static Order getOrderEntity(int id) {
		String getOrderUrl = orderServiceUrl + "/{id}";
		LinkedHashMap<String, Integer> urlParams = new LinkedHashMap<String, Integer>();
		urlParams.put("id", id);

		ResponseEntity<Order> responseEntity = restTemplate.getForEntity(getOrderUrl, Order.class, urlParams);

		if (responseEntity.getStatusCode() == HttpStatus.NOT_FOUND) {
			throw new ResourceNotFoundException("Order id: " + id);
		}
		
		HttpHeaders headers = responseEntity.getHeaders();
		MediaType contentType = headers.getContentType();
		System.out.println("Media type returned by REST lookup: " + contentType);
		return responseEntity.getBody();
	}
	   
	public static Order createOrder(Order newOrder) {
		return restTemplate.postForObject(orderServiceUrl, newOrder,
				Order.class);
	}

	public static void updateOrder(Order order) {
		restTemplate.put(orderServiceUrl + "/{id}", order, order.getId());
	}
	
	public static void deleteOrder(int id) {
		restTemplate.delete(orderServiceUrl + "/{id}", id);
	}

	/* Test the different capabilities:
	 * 		1.  Create a new order
	 * 		2.  Retrieve the order
	 * 		3.  Update the order
	 * 		4.  Retrieve the updated order
	 * 		5.  Delete the order
	 *  	6.  Check that order doesn't exist anymore
	 */
	public static void main(String[] args) {
		ApplicationContext appContext = new ClassPathXmlApplicationContext("service.xml");
		Order newOrder, createdOrder, retrievedOrder;
		int createdOrderId;
		String getOrderUrl = orderServiceUrl + "orders/" +"{id}";
		
		/*
		RestTemplate restTemplate = new RestTemplate();
		newOrder = new Order("ZG4568", 250.75F);
		createdOrder = restTemplate.postForObject(orderServiceUrl, newOrder, Order.class);
		
		createdOrderId = createdOrder.getId();
		retrievedOrder = restTemplate.getForObject(getOrderUrl, Order.class, createdOrderId);
		*/

		/*  1.  Create a new order  */
		newOrder = new Order("ZG4568", 250.75F);
		createdOrder = createOrder(newOrder);

		/*  2.  Retrieve the order  */
		createdOrderId = createdOrder.getId();
		retrievedOrder = getOrder(createdOrderId);
		System.out.println("Retrieved order using REST: \n" + retrievedOrder);
		
		/*  3.  Update the order  */
		retrievedOrder.setAmount(287.56F);
		updateOrder(retrievedOrder);
		
		/*  Retrieve the updated order  */
		retrievedOrder = getOrder(createdOrderId);
		System.out.println("Retrieved updated order using REST: \n" + retrievedOrder);
		
		/*  5.  Delete the order  */
		deleteOrder(createdOrderId);
		
		/*  6.  Check that order doesn't exist anymore */
		try {
			retrievedOrder = getOrderEntity(createdOrderId);
			/* We should get an exception, so the following line should not be executed */
			System.out.println("***Unexpected behavior: " + createdOrderId + " was not successfully removed\n");
		} catch (HttpClientErrorException ex) {
			System.out.println("Exception when order is not found: " + ex + "\n");
			System.out.println("Order " + createdOrderId + " has been removed\n");
		}
	}
}
