package npu.orderapp.domain;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class DateAdapter extends XmlAdapter<String, Date> {

    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    public String marshal(Date date) throws Exception {
    	//SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    	dateFormat.setTimeZone(TimeZone.getTimeZone( "UTC" ));
		String formattedDate = dateFormat.format(date);
		return formattedDate;
    }

    @Override
    public Date unmarshal(String v) throws Exception {
    	dateFormat.setTimeZone(TimeZone.getTimeZone( "UTC" ));
        return dateFormat.parse(v);
    }

}
