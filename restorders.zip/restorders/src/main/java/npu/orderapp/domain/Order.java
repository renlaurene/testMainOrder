package npu.orderapp.domain;

import java.text.NumberFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.codehaus.jackson.annotate.JsonTypeInfo.As;
import org.codehaus.jackson.annotate.JsonTypeInfo.Id;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@XmlRootElement(name="order")  
public class Order {
	private Integer id;
	private Date date;
	@XmlElement(name="cusnum")
	private String cusnum;
	private float amount;
	private static NumberFormat dlrFormatter = NumberFormat.getCurrencyInstance();
	
	public Order() {
	}
	
	public Order(Date orderDate, String cusNumber) {
		date = orderDate;
		cusnum = cusNumber;
	}
	
	public Order(String cusNumber, float amt) {
		cusnum = cusNumber;
		amount = amt;
	}
	
	Date todaysDate = new Date();

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	/* JsonSerialize annotation is used by Jackson (org.codehaus.jackson.map.annotate.JsonSerialize) to specify how to convert a field
	   to the representation you want used in JSON.   See the class CustomDateSerializer which does the conversion.   Without this, the 
	   date appears as the long representation -- you can uncomment the annotation to see how the Date is represented by default in JSON.
	*/
	@JsonSerialize(using = CustomDateSerializer.class)
	@XmlElement(name = "date", required = true) 
	@XmlJavaTypeAdapter(DateAdapter.class)  // Likewise, this class has methods to convert a date to/from XML in the format we want
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getCusnum() {
		return cusnum;
	}
	
	public boolean equals(Object otherObj) {
		Order otherOrder;
		
		if (!(otherObj instanceof Order)) return false;
		otherOrder = (Order) otherObj;
		if (id.equals(otherOrder.id) && (id.intValue() != 0) && cusnum.equals(otherOrder.cusnum)) {
			return true;
		}
		
		return false;
	}
	
	public boolean dataEqualWithoutDate(Object otherObj) {
		Order otherOrder;
		float amtDiff;
		
		if (!(otherObj instanceof Order)) return false;
		otherOrder = (Order) otherObj;
		
		amtDiff = amount - otherOrder.amount;
		if (cusnum.equals(otherOrder.cusnum) && (amtDiff < .000000001)) {
			return true;
		}
		
		return false;
	}
	
	public String toString() {
		String amountStr = dlrFormatter.format(amount);
		String orderStr = ("Order(id: " + id + " date: " + date + " cusnum: " + cusnum  + " amount: " + amountStr + ")");
		return orderStr;
	}
	
	
}

