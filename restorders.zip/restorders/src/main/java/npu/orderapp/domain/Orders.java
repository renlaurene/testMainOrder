package npu.orderapp.domain;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Orders extends ArrayList<Order> {
	
	/*  Need a default constructor when using JAXB */
	public Orders() {
	}

	/*
	 * Must return List<Order> for JAXB to marshal (not ArrayList<Order>), also
	 * give the XML tag for each element of the list
	 */
	@XmlElement(name = "order")
	public List<Order> getOrders() {
		return this;
	}

	public void setOrders(List<Order> orders) {
		this.addAll(orders);
	}
}
