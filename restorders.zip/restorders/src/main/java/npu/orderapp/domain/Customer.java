package npu.orderapp.domain;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Customer {
	private String name;
	private String cusnum;
	
	/*  required by JAXB */
	public Customer() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCusnum() {
		return cusnum;
	}

	public void setCusnum(String cusnum) {
		this.cusnum = cusnum;
	}
	
}
