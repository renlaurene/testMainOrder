package npu.orderapp.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;

import npu.orderapp.domain.Order;
import npu.orderapp.domain.Orders;

import org.springframework.stereotype.Service;

@Service
public class RestOrderServiceImpl implements RestOrderService {
	/* Mock the database with these data members */
	private Random random = new Random(System.currentTimeMillis());
	private LinkedHashMap<Integer,Order> orderMap = new LinkedHashMap<Integer,Order>();
	
	public List<Order> getOrderList() {
		return new ArrayList<Order>(orderMap.values());
	}
	
	public Orders getOrders() {
		Orders retrievedOrders = new Orders();
		ArrayList<Order> retrievedList;
		
		retrievedList = new ArrayList<Order>(orderMap.values());
		retrievedOrders.setOrders(retrievedList);
		System.out.println(retrievedOrders);
		return retrievedOrders;
	}
	
	public Order getOrder(int orderId) {
			return orderMap.get(orderId);
	}
	
	
	public Order createOrder(Order newOrder) {
		Date todaysDate = new Date();
		int newOrderId = getOrderId();
		newOrder.setId(newOrderId);
		newOrder.setDate(todaysDate);
		orderMap.put(newOrderId, newOrder);

		return newOrder;
	}
	
	public Order updateOrder(Order order) {
		int orderId = order.getId();
		
		if (orderMap.containsKey(orderId)) {
			orderMap.put(orderId, order);
			return order;
		}
		
		return null;
	}
	
	public boolean deleteOrder(int orderId) {
		if (orderMap.containsKey(orderId)) {
			orderMap.remove(orderId);
			return true;   /* order removed */
		}
		
		return false;  /* Unknown order */
	}
	
	/* Generate some random order ids to make things more interesting.  */
	private Integer getOrderId() {
		return Math.abs(random.nextInt() % 1000);
	}
}
