package npu.orderapp.services;

import java.util.List;

import npu.orderapp.domain.Order;
import npu.orderapp.domain.Orders;

public interface RestOrderService {
	public Orders getOrders();
	public List<Order> getOrderList();
	
	public Order getOrder(int orderId);
	public Order createOrder(Order newOrder);
	public Order updateOrder(Order order);
	public boolean deleteOrder(int orderId);
}
