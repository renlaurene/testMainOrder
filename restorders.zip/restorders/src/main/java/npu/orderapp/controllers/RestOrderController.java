package npu.orderapp.controllers;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import npu.orderapp.domain.Order;
import npu.orderapp.domain.Orders;
import npu.orderapp.services.RestOrderService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

/*   This Controller uses the HttpMessageConverters to generate JSON/XML  */
/*   The Content Negotiating Bean for the HttpMessageConverters is "contentNegotiationManager".
 *   To change the way content negotiation is done, change that bean.
 */
@Controller
@RequestMapping("/orders")
public class RestOrderController {
private static Logger logger = Logger.getLogger(RestOrderController.class);
	
	@Autowired
	private RestOrderService orderService;
	
	/* Get a list of all the Orders.
	 * Some example URLs:
	 *      http://localhost:8080/restorders/orders                   (order list will be in XML)
	 *      http://localhost:8080/restorders/orders?mediaType=json    (order list will be in JSON)
	 *      
	 *      Note the following has been turned off by configuring the content negotiating bean (URL suffix):
	 *           http://localhost:8080/restorders/orders.json
	 */
	@RequestMapping(method=RequestMethod.GET)
	@ResponseBody
	public Orders getOrders(HttpServletRequest request) {
		logger.debug("Rest request to retrieve all Orders");
		return orderService.getOrders();
	}
	
	@RequestMapping(value="/{orderId}",  method=RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Order> getOrder(@PathVariable Integer orderId, @RequestHeader("Accept") String accept) 
	{
		Order order;
		
		logger.debug("Retrieving Rest request for order: " + orderId + " requested MIME type: " + accept);
		order = orderService.getOrder(orderId);
		if (order != null) {
			return new ResponseEntity<Order>(order, HttpStatus.OK);
		} else {
			logger.debug("Request for Order " + orderId + " was not found");
			return new ResponseEntity<Order>(HttpStatus.NOT_FOUND);
		}
	}
	
	/* Create a new order -- use a POST command and make sure to provide the Order data in the Request Content. 
	 * Example URL to do a POST:  http://localhost:8080/restorders/orders
	 */
	@RequestMapping(method=RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Order> createOrder(@RequestBody Order newOrder, HttpServletResponse response)   {
		int newOrderId;
		URI uriOfNewOrder;
		Order createdOrder;
		Map<String, String> paramMap = new LinkedHashMap<String, String>();
		
		createdOrder = orderService.createOrder(newOrder);
		logger.debug("Created new order: " + newOrder);
		
		/* Build the location header */
		newOrderId = createdOrder.getId();
		paramMap.put("id", newOrderId+"");
		uriOfNewOrder = ServletUriComponentsBuilder.fromCurrentContextPath()
				.pathSegment( "orders/{id}" )
				.buildAndExpand(paramMap)
				.toUri();
		response.addHeader("location", uriOfNewOrder.toString());
		
		return new ResponseEntity<Order>(createdOrder, HttpStatus.CREATED);
	}
	
	/* Update an existing order -- you'll need to use an HTTP PUT command and provide the orderId in the URL.
	 * Example URL:  http://localhost:8080/restorders/orders/{orderId}
	 */
	@RequestMapping(value="/{orderId}",  method=RequestMethod.PUT)
	@ResponseBody
	public ResponseEntity<Order> updateOrder(@RequestBody Order orderFromClient, HttpServletResponse response)   {
		int orderId;
		URI uriOfNewOrder;
		Order modifiedOrder;
		Map<String, String> paramMap = new LinkedHashMap<String, String>();
		
		orderId = orderFromClient.getId();
		modifiedOrder = orderService.updateOrder(orderFromClient);
		if (modifiedOrder == null) {
			logger.debug("Attempt to modify Order failed.  Order " + orderId + " was not found");
			return new ResponseEntity<Order>(HttpStatus.NOT_FOUND);
		}
		
		logger.debug("Modified order: " + modifiedOrder);
		
		/* Build the location header */
		orderId = modifiedOrder.getId();
		paramMap.put("id", orderId+"");
		uriOfNewOrder = ServletUriComponentsBuilder.fromCurrentContextPath()
				.pathSegment( "orders/{id}" )
				.buildAndExpand(paramMap)
				.toUri();
		response.addHeader("location", uriOfNewOrder.toString());
		
		return new ResponseEntity<Order>(HttpStatus.OK);
	}
	
	/* Delete an order -- you'll need to use an HTTP DELETE command and provide the orderId in the URL. 
	 * Example URL:  http://localhost:8080/restorders/orders/{orderId}
	 */
	@RequestMapping(value="/{orderId}",  method=RequestMethod.DELETE)
	public ResponseEntity<Order> deleteOrder(@PathVariable Integer orderId) 
	{
		boolean orderRemoved;
		
		logger.debug("Rest request to delete order: " + orderId);
		orderRemoved = orderService.deleteOrder(orderId);
		if (orderRemoved) {
			logger.debug("Deleted Order id: " + orderId);
			return new ResponseEntity<Order>(HttpStatus.OK);
		} else {
			logger.debug("Attempt to delete order failed. Order id: " + orderId + " was not found");
			return new ResponseEntity<Order>(HttpStatus.NOT_FOUND);
		}
	}
	
}
