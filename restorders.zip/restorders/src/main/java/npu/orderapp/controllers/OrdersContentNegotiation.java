package npu.orderapp.controllers;

import npu.orderapp.domain.Order;
import npu.orderapp.domain.Orders;
import npu.orderapp.services.RestOrderService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/* This demonstrates content negotiation using ViewResolvers (instead of HttpMessageConverters that
 * are used when the @ResponseBody annotation is used in the controller).   Note that instead of
 * using @ResponseBody, we return a ModelAndView.  For the model part we simply add our object.
 * If the client is requesting HTML, the view will be order.jsp.
 */
@Controller
@RequestMapping("/zorders")
public class OrdersContentNegotiation {
private static Logger logger = Logger.getLogger(OrdersContentNegotiation.class);
	
	@Autowired
	private RestOrderService orderService;
	
	/* Note that instead of
  	   using @ResponseBody, we return a ModelAndView.  For the model part we simply add our object.
       If the client is requesting HTML, the view will be rendered by the .jsp page.
       BUT because we have multiple view resolvers, other views can render the model object.  
       Try these 4 different URLs to see the different View Resolution (you may need to POST some orders first):
            http://localhost:8080/restorders/zorders
            http://localhost:8080/restorders/zorders.xml
            http://localhost:8080/restorders/zorders.json
            http://localhost:8080/restorders/zorders?format=json
    */
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getOrders() {
		logger.debug("Get all orders");
		Orders orderList =  orderService.getOrders();
		
		ModelAndView result = new ModelAndView("ordersView", "orderList", orderList);
		return result;
	}
	
	@RequestMapping(value="/{orderId}",  method=RequestMethod.GET)
	public ModelAndView getOrder(@PathVariable Integer orderId) {
		logger.debug("Looking up order id: " + orderId);
		Order retrievedOrder =  orderService.getOrder(orderId);
		logger.debug("Found order: " + retrievedOrder);
		
		ModelAndView result = new ModelAndView("order", "order", retrievedOrder);
		return result;
	}
}
